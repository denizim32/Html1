# Repository : https://github.com/alikemaluysal/SiliconmadeFrontendGorev

> **Javascript ile ilgili;**

- Sayfa 2'de Üyelik Sözleşmesi ve Aydınlatma Metni kutuları işaretlemeden "Üye Ol" butonuna basılırsa sayfadaki gibi formun üst tarafında uyarı çıkmasını sağlayın.
- Sayfa 2'de alanlar boş bırakılırsa formun üst kısmındaki uyarı kutusunda hangi form alanlarının boş bırakıldığını yazın. (Örnek: Adınızı boş bıraktığınız için form gönderilemedi.)

> **Sayfalarla ilgili notlar:**

- Sayfa 2'yi yaparken "Üye Olun" Başlığının konumunun farklı ekran boyutları için görseldeki gibi görünmesini sağlayın.
- Sayfa 3'ü yaparken mobil görünümde sağ taraftaki görselin olmadığını fark edin, buna göre farklı ekran boyutları için düzenleyin.
- Sayfa 4'ü yaparken saffanın orjinalinden gerekli nüansları inceleyebilirsiniz: https://www.dr.com.tr/X
  Burada;
  Çizimin arka plan fotoğrafı olduğunu fark edin. (css'ten background özelliğini kullanmanız gerekecek)
  404 yazısının farklı renklerde yazdığını fark edin.
  Aşağıdaki butonların üstüne gelindiğinde renginin değiştiğini fark edin. (Bu görüntüyü Bootstrap ile sağlayamayamazsanız css'ten :hover kullanımını inceleyebilirsiniz.)
